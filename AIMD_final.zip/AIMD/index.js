/* function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }
    

    // Simple responses
    if (input == "hello") {
        return "Hello there!";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    } else {
        return "Try asking something else!";
    }
} */

import { Configuration, OpenAIApi } from "openai";
import express from "express";
import bodyParser from "body-parser";
import cors from "cors";

const configuration = new Configuration({
    organization: "org-YeULaraFGsLBPXACZRz3T4Op",
    apiKey: "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",
});

const openai = new OpenAIApi(configuration);

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

app.post("/", async (req, res) => {

    const { messages } = req.body;

    console.log(messages)
    const completion = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [
            {"role": "system", "content": "Your name is AiMD and you are a chatbot who's purpose it to be a Doctor's assistant and ONLY responds to medical questions"},
            ...messages
        ]
    })

    res.json({
        completion: completion.data.choices[0].message
    })

});

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});

// Fetching the data from Flask

import fetch from 'node-fetch';

fetch('http://localhost:5000/receive_data', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({search_query: 'Doctor'})
})
.then(response => response.json())
.then(data => {
  console.log('Received data:', data);
})
.catch(error => {
  console.error('Error:', error);
});


